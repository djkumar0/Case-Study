package com.empManage.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.empManage.entity.Employee;

import com.empManage.service.EmployeeServiceImpl;

@RestController
public class MyController {
	
	@Autowired
	private EmployeeServiceImpl empService;
	
	@PostMapping("/add")
	public String add(@RequestBody Employee employee) {
		empService.saveEmp(employee);
		return "Employee Added Successfully";
	}
	
	@GetMapping("/getAll")
	public List<Employee> getAllEmp(){
		return empService.getAll();
	}
	
	@DeleteMapping("/delete")
		public void delete(@RequestBody Employee employee) {
			empService.deleteEmp(employee);
			//return ("Employee Deleted Successfully");
		}
	
	@PutMapping("/update")
	
		public Employee update(@RequestBody Employee employee) 
		{
			return empService.updateEmp(employee);
		}
	@GetMapping("/search/{empid}")
	public Employee searchById(@PathVariable int empid ){
		return empService.searchbyId(empid);
	}
	
}

