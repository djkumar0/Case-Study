package com.empManage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.empManage.entity.Employee;
import com.empManage.repo.EmployeeRepo;

@Service
public class EmployeeServiceImpl implements EmployeeService{

	@Autowired
	EmployeeRepo em;

	public EmployeeServiceImpl(EmployeeRepo employeeRepo) {
		this.em = employeeRepo;
	}
	
	@Override
	public Employee saveEmp(Employee employee)
	{
		return em.save(employee);
		
	}
	
	@Override
	public List<Employee> getAll()
	{
		return em.findAll();
		//return null;
		
	}
	
	@Override
	public Employee updateEmp(Employee employee)
	{
		return em.save(employee);
	}
	@Override
	public void  deleteEmp(Employee employee)
	{
		em.delete(employee);
	}
	
	@Override
	public Employee searchbyId(int empid) {
		// TODO Auto-generated method stub
		return em.findById(empid).orElse(null);
	}

}
