package com.empManage.service;

import java.util.List;

import com.empManage.entity.Employee;

public interface EmployeeService {
	
	public Employee saveEmp(Employee employee);
	public List<Employee> getAll();
	public Employee updateEmp(Employee employee);
	public void  deleteEmp(Employee employee);
	public Employee searchbyId(int empid);

}
